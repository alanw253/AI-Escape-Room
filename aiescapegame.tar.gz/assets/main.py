import pygame
import sys
import time
import asyncio

# --- Initialization ---
pygame.init()
pygame.mixer.init()

# --- Constants ---
# Safely set back to 800x600 to prevent scaling memory crashes
WIDTH, HEIGHT = 800, 600
FPS = 60
TIMER_DURATION = 30 * 60

WHITE, BLACK, RED = (255, 255, 255), (0, 0, 0), (255, 0, 0)
LIGHT_GREEN, GOLD = (200, 255, 200), (255, 215, 0)
BLUE, COMPLETED_GREEN, UNCOMPLETED_GREY = (50, 50, 200), (0, 200, 0), (150, 150, 150)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("AIEscape - AI Scenario Game")
clock = pygame.time.Clock()

# --- Fonts ---
font = pygame.font.SysFont('arial', 20)
small_font = pygame.font.SysFont('arial', 14)
large_font = pygame.font.SysFont('arial', 40, bold=True)
title_font = pygame.font.SysFont('arial', 60, bold=True)
try:
    comic_sans_font = pygame.font.SysFont('Comic Sans MS', 24, bold=True)
except:
    comic_sans_font = pygame.font.SysFont('arial', 24, bold=True)

# --- Asset Loading ---
lab_bg = pygame.image.load("assets/lab.png")
character_img = pygame.image.load("assets/character.png")
pygame.mixer.music.load("assets/music.ogg")
pygame.mixer.music.play(-1)

# --- Game Variables ---
char_x, char_y = 50, 500
char_speed = 4
game_state = "START_SCREEN"
solved_puzzles = [False] * 10
incorrect_attempts_count = [0] * 10
user_input = ''
escape_code_input = ''
current_puzzle = None
input_active = False
escape_code_active = False
start_time = 0
total_incorrect_attempts = 0

# --- Puzzles (Multiple Choice Enforced, Hints Removed) ---
puzzles = [
    {
        "id": 1, 
        "question": "I want to brainstorm 5 completely new, creative ideas for tasks to do on a school trip to Auckland Zoo.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "Gemini"
    },
    {
        "id": 2, 
        "question": "I have a 40-page Ministry of Education curriculum update PDF and I want to instantly pull out the key changes for intermediate schools.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "NotebookLM"
    },
    {
        "id": 3, 
        "question": "I want to paste last term's student math assessment data to spot trends.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "NotebookLM"
    },
    {
        "id": 4, 
        "question": "I need to write a catchy, rhyming poem to introduce a science lesson on acids and bases to my class.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "Gemini"
    },
    {
        "id": 5, 
        "question": "I have gathered 15 different articles and text snippets on a particular literacy concept and I want to use those materials to plan a lesson.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "NotebookLM"
    },
    {
        "id": 6, 
        "question": "I want to draft a polite email response to an upset parent, ensuring I keep a professional and calm tone.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "Gemini"
    },
    {
        "id": 7, 
        "question": "I want to generate a 10-question multiple-choice quiz based on a science lesson I have created on animal adaptation.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "NotebookLM"
    },
    {
        "id": 8, 
        "question": "I want advice on how to solve a technical problem with my computer.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "Gemini"
    },
    {
        "id": 9, 
        "question": "I want to drop in my messy, rough notes from three weeks of team meetings and organise them into clear, actionable bullet points.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "NotebookLM"
    },
    {
        "id": 10, 
        "question": "I want to generate a fictional, creative storybook script about a time-travelling student to read to my class.\n\n[Options: Gemini / NotebookLM]", 
        "answer": "Gemini"
    },
]
# Adjusted terminal node placements so they don't block the new escape location
puzzle_positions = [(150, 350), (350, 120), (550, 140), (700, 150), (160, 450), (350, 380), (550, 360), (700, 300), (300, 520), (550, 520)]

# --- Helper Functions ---
def wrap_text(text, font_obj, max_width):
    lines = []
    paragraphs = text.split('\n')
    for paragraph in paragraphs:
        if not paragraph:
            lines.append("")
            continue
        words = paragraph.split(' ')
        current_line = []
        for word in words:
            test_line = " ".join(current_line + [word])
            if font_obj.render(test_line, True, BLACK).get_width() < max_width:
                current_line.append(word)
            else:
                lines.append(" ".join(current_line))
                current_line = [word]
        lines.append(" ".join(current_line))
    return lines

def draw_timer():
    elapsed = time.time() - start_time
    remaining = max(0, TIMER_DURATION - int(elapsed))
    timer_text = font.render(f"Time Left: {remaining//60:02}:{remaining%60:02}", True, BLACK)
    screen.blit(timer_text, (10, 10))

def draw_puzzle_tracker():
    bx, by, bw, bh = WIDTH - 160, 10, 150, 200
    pygame.draw.rect(screen, WHITE, (bx, by, bw, bh), 0, 5)
    pygame.draw.rect(screen, BLACK, (bx, by, bw, bh), 2, 5)
    screen.blit(small_font.render("Scenarios Solved:", True, BLACK), (bx + 10, by + 5))
    for i in range(10):
        color = COMPLETED_GREEN if solved_puzzles[i] else UNCOMPLETED_GREY
        ix = bx + 10 + (i % 3) * 45
        iy = by + 40 + (i // 3) * 45
        pygame.draw.rect(screen, color, (ix, iy, 20, 20))
        screen.blit(small_font.render(str(i+1), True, BLACK), (ix + 5, iy - 15))

# --- Main Game Loop ---
async def main():
    global game_state, char_x, char_y, user_input, escape_code_input, current_puzzle, input_active, escape_code_active, start_time, total_incorrect_attempts

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: 
                running = False
            
            if game_state == "START_SCREEN":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if pygame.Rect(WIDTH//2-75, HEIGHT-100, 150, 50).collidepoint(event.pos):
                        game_state = "PLAYING"
                        start_time = time.time()

            elif game_state == "PLAYING":
                if input_active and event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        idx = current_puzzle["id"] - 1
                        if user_input.strip().lower() == current_puzzle["answer"].lower():
                            solved_puzzles[idx] = True
                            input_active = False
                            user_input = ""
                        else:
                            user_input = ""
                            incorrect_attempts_count[idx] += 1
                            total_incorrect_attempts += 1
                    elif event.key == pygame.K_BACKSPACE: 
                        user_input = user_input[:-1]
                    else: 
                        user_input += event.unicode
                
                elif escape_code_active and event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        if escape_code_input.strip() == "5":
                            game_state = "END_SCREEN"
                        else:
                            escape_code_input = ""
                            total_incorrect_attempts += 1
                    elif event.key == pygame.K_BACKSPACE: 
                        escape_code_input = escape_code_input[:-1]
                    else: 
                        escape_code_input += event.unicode

        if game_state == "START_SCREEN":
            screen.fill(BLACK)
            title = title_font.render("AIEscape", True, WHITE)
            screen.blit(title, title.get_rect(center=(WIDTH//2, HEIGHT//6)))
            
            instr = [
                "Tom Beckett is locked in the AI Staffroom!",
                "For each scenario, enter the exact option: Gemini or NotebookLM.",
                "Use the ARROW KEYS to move and activate terminals.",
                "When all 10 scenarios are solved, head to the escape exit,",
                "and answer the master question 'How many times was the answer NotebookLM?'",
                "to open the final airlock door!"
            ]
            for i, line in enumerate(instr):
                txt = font.render(line, True, WHITE)
                screen.blit(txt, txt.get_rect(center=(WIDTH//2, HEIGHT//3 + i*40)))
            
            pygame.draw.rect(screen, BLUE, (WIDTH//2-75, HEIGHT-100, 150, 50), border_radius=10)
            screen.blit(font.render("START", True, WHITE), (WIDTH//2-30, HEIGHT-88))

        elif game_state == "PLAYING":
            scaled_bg = pygame.transform.scale(lab_bg, (WIDTH, HEIGHT))
            screen.blit(scaled_bg, (0, 0))
            screen.blit(character_img, (char_x, char_y))
            
            # Movement
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]: char_x -= char_speed
            if keys[pygame.K_RIGHT]: char_x += char_speed
            if keys[pygame.K_UP]: char_y -= char_speed
            if keys[pygame.K_DOWN]: char_y += char_speed
            char_x, char_y = max(0, min(WIDTH-40, char_x)), max(0, min(HEIGHT-40, char_y))

            # Collision Logic
            char_rect = character_img.get_rect(topleft=(char_x, char_y))
            any_puz = False
            for i, (px, py) in enumerate(puzzle_positions):
                if not solved_puzzles[i] and char_rect.colliderect(pygame.Rect(px-25, py-25, 50, 50)):
                    any_puz = True
                    if current_puzzle is None or current_puzzle["id"]-1 != i:
                        user_input = ""
                        current_puzzle, input_active = puzzles[i], True
                    break
            if not any_puz: 
                input_active, current_puzzle = False, None

            # Door collision detection scaled to 800x600 size:
            # X = WIDTH // 4 -> 200 (one-quarter from left)
            # Y = HEIGHT // 4 -> 150 (one-quarter down)
            if all(solved_puzzles) and char_rect.colliderect(pygame.Rect(200, 150, 100, 100)):
                escape_code_active = True
            else: 
                escape_code_active = False

            draw_timer()
            draw_puzzle_tracker()

            if input_active:
                pygame.draw.rect(screen, LIGHT_GREEN, ((WIDTH-600)//2, (HEIGHT-320)//2, 600, 320), border_radius=10)
                lines = wrap_text(current_puzzle["question"], comic_sans_font, 560)
                for idx, l in enumerate(lines): 
                    screen.blit(comic_sans_font.render(l, True, BLACK), ((WIDTH-600)//2 + 20, (HEIGHT-320)//2 + 15 + idx*32))
                pygame.draw.rect(screen, WHITE, ((WIDTH-600)//2 + 20, (HEIGHT-320)//2 + 265, 560, 40))
                screen.blit(font.render(user_input, True, BLACK), ((WIDTH-600)//2 + 25, (HEIGHT-320)//2 + 270))

            if escape_code_active:
                pygame.draw.rect(screen, GOLD, ((WIDTH-600)//2, (HEIGHT-400)//2, 600, 400), border_radius=10)
                
                final_msg = "All AI terminals bypassed! Final Terminal Security Check:\n\nHow many times was NotebookLM the Answer?\n\nType the correct number count inside the panel box below."
                
                wrapped_lines = wrap_text(final_msg, comic_sans_font, 560)
                for idx, line in enumerate(wrapped_lines):
                    screen.blit(comic_sans_font.render(line, True, BLACK), ((WIDTH-600)//2 + 20, (HEIGHT-400)//2 + 30 + idx * 35))
                
                pygame.draw.rect(screen, WHITE, ((WIDTH-600)//2 + 20, (HEIGHT-400)//2 + 340, 560, 40))
                screen.blit(font.render(escape_code_input, True, BLACK), ((WIDTH-600)//2 + 25, (HEIGHT-400)//2 + 345))

        elif game_state == "END_SCREEN":
            screen.fill(BLACK)
            screen.blit(large_font.render("LAB ESCAPED!", True, GOLD), (WIDTH//2 - 130, HEIGHT//2 - 20))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

if __name__ == '__main__':
    asyncio.run(main())
